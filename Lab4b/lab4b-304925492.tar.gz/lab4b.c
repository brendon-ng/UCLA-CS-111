//NAME: Brendon Ng
//EMAIL: brendonn8@gmail.com
//ID: 304925492

#include <stdio.h>
#include <mraa.h>


int main(int argc, char** argv){
	printf("HI");
	
}
